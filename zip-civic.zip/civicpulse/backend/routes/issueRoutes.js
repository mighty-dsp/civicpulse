const express = require('express');
const multer = require('multer');
const router = express.Router();
const Issue = require('./models/Issue');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  },
});
const upload = multer({ storage });

router.post('/', upload.single('image'), async (req, res) => {
  try {
    const { title, description, location } = req.body;
    let imageUrl = '';
    if (req.file) imageUrl = `/uploads/${req.file.filename}`;

    const newIssue = new Issue({ title, description, location, imageUrl });
    await newIssue.save();
    res.status(201).json(newIssue);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/', async (req, res) => {
  try {
    const issues = await Issue.find().sort({ createdAt: -1 });
    res.json(issues);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
