import { Link } from 'react-router-dom';

export default function Login() {
  return (
    <div style={{ maxWidth: 400, margin: 'auto', padding: 20 }}>
      <h1>Login</h1>
      <form>
        <label>Email:</label><br />
        <input type="email" name="email" required /><br /><br />
        <label>Password:</label><br />
        <input type="password" name="password" required /><br /><br />
        <button type="submit">Login</button>
      </form>
      <p>
        Don't have an account? <Link to="/register">Register here</Link>
      </p>
    </div>
  );
}
