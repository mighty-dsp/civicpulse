export default function ViewIssues() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Submitted Issues</h1>
      <p>This page will show all reported issues with status updates.</p>
    </div>
  );
}
