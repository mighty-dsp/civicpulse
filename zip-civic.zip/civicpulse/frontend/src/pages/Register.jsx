import { Link } from 'react-router-dom';

export default function Register() {
  return (
    <div style={{ maxWidth: 400, margin: 'auto', padding: 20 }}>
      <h1>Register</h1>
      <form>
        <label>Name:</label><br />
        <input type="text" name="name" required /><br /><br />
        <label>Email:</label><br />
        <input type="email" name="email" required /><br /><br />
        <label>Password:</label><br />
        <input type="password" name="password" required /><br /><br />
        <button type="submit">Register</button>
      </form>
      <p>
        Already have an account? <Link to="/login">Login here</Link>
      </p>
    </div>
  );
}
