export default function ReportIssue() {
  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: 20 }}>
      <h1>Report an Issue</h1>
      <form>
        <label>Title:</label><br />
        <input type="text" name="title" required /><br /><br />
        <label>Description:</label><br />
        <textarea name="description" rows="5" required></textarea><br /><br />
        <label>Location:</label><br />
        <input type="text" name="location" required /><br /><br />
        <label>Upload Image (optional):</label><br />
        <input type="file" name="image" accept="image/*" /><br /><br />
        <button type="submit">Submit Issue</button>
      </form>
    </div>
  );
}

