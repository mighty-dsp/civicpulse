import { Link } from 'react-router-dom';

export default function Dashboard() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Dashboard</h1>
      <nav>
        <Link to="/report">Report an Issue</Link> |{' '}
        <Link to="/issues">View Issues</Link> |{' '}
        <Link to="/login">Logout</Link>
      </nav>
      <p>Welcome to CivicPulse! Track your reported civic issues here.</p>
    </div>
  );
}
